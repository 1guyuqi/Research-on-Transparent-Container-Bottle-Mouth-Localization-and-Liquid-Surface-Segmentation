## YOLO-Seg 数据集

本数据集由 `video_1920_1080_anno.json` + `images/` 自动生成。

### 目录结构

- `images/train|val|test/`：图片（默认软链接到原始 `images/`）
- `labels/train|val|test/`：YOLO-Seg 标签（与图片同名 `.txt`）
- `data.yaml`：Ultralytics 训练配置
- `dataset_stats.json`：生成统计

### 标签格式（每行一个实例）

`class_id x_center y_center w h x1 y1 x2 y2 ... xn yn`

坐标均已按 W=1920, H=1080 归一化到 [0,1]。

### 关于 attri == -1

本次生成使用参数 `--minus1 map`：

- `skip`：忽略这些实例（推荐，保证可训练）
- `map`：把 -1 映射成新类 `unknown`
- `keep`：写 -1（Ultralytics 训练通常不接受负类 id，不保证可训练）

### 训练命令示例（YOLOv8-seg）

```bash
yolo segment train data=/Users/mac/Downloads/code/python/pythonProject1/prp/yolo_seg_dataset_no_test/data.yaml model=yolov8n-seg.pt
```
